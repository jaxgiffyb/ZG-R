# Unlimited-GooglePhotosBackupMod
Magisk Module to enable Unlimited google photos backup. <br>
zygisk must enabled, for using this mod.

# Spoofing

it spoof targeted app (Google photos app ) as a Pixel xl Device to get the unlimited Backup.
<br>
`` <feature name="com.google.android.apps.photos.NEXUS_PRELOAD" />``
<br>
`` <feature name="com.google.android.apps.photos.nexus_preload" /> ``

# Installation 
<br>
Download the zip |
<a href="https://github.com/Kolass2004/Unlimited-GooglePhotosBackupMod/releases/download/v2.1/gphotos-unlimited-mod-v2.1-hotfix.zip" download >Download</a>

flash the module zip in your root managers like Magisk/Apatch/kernalSU
``Zygisk must enabled``
reboot and enjoy
